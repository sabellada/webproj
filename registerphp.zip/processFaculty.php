<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "dcs";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}

	$password = md5($_POST["password"]);
	$bday = str_replace("-","", $_POST["bday"]);
	$insertUser_sql = "INSERT INTO users (user_id, user_type, username, password, first_name, middle_name, last_name, gender, birth_date, address, gbox_acct) VALUES ('', '2', '" . $_POST["fid"] . "', '" . $password . "', '" . $_POST["fname"] . "', '" . $_POST["mname"] . "', '" . $_POST["lname"] . "', '" . $_POST["gender"] . "', '" . $bday . "', '" . $_POST["address"] . "', '" . $_POST["gbox"] . "')";
	$insertUser_result = mysqli_query($conn, $insertUser_sql);
	if($insertUser_result == true)
	{
		$queryUserId_sql = "SELECT user_id FROM users WHERE username='" . $_POST["fid"] . "'";
		$queryUserId_result = mysqli_query($conn, $queryUserId_sql);
		$row_userid = mysqli_fetch_assoc($queryUserId_result);

		$insertFaculty_sql = "INSERT INTO faculty (user_id, faculty_id, status, is_admin) VALUES ('" . $row_userid["user_id"] . "', '" . $_POST["fid"] . "', '0', '0')";
		$insertFaculty_result = mysqli_query($conn, $insertFaculty_sql);
	}
?>